package com.squaretech.system.barcode;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;


/**
 * Created by sopnil on 17/7/15.
 */
public class ActivitySplashScreen extends Activity {

    public static  final int SPLASH_TIME_OUT =3000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash_screen);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               // if (Pref.getmInstance(ActivitySplashScreen.this).getClassSectionID().equalsIgnoreCase("")){
                 if ( ! Pref.getmInstance(ActivitySplashScreen.this).getLoginStatus()){
                    Intent intent = new Intent(ActivitySplashScreen.this , LoginActivity.class);
                    startActivity(intent);
                    finish();
                }else {
                    Intent intent = new Intent(ActivitySplashScreen.this , MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, SPLASH_TIME_OUT);
    }


}

