package com.squaretech.system.barcode;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by squaretech on 1/3/17.
 */
public class RegistrationActivity extends AppCompatActivity {

    EditText firstName,lastName,address, mobileNo;
    public static EditText emailID, password;
    Button btn_register;



    String strEmailAddress;
    String regEx ="^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,4}$";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        firstName = (EditText) findViewById(R.id.edt_firstName);
        lastName= (EditText) findViewById(R.id.edt_lastName);
        address= (EditText) findViewById(R.id.edt_address);
        mobileNo = (EditText) findViewById(R.id.edt_mobno);
        emailID= (EditText) findViewById(R.id.edt_email);
        password = (EditText) findViewById(R.id.edt_password);

        btn_register= (Button) findViewById(R.id.btn_register);


        btn_register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(firstName.getText().toString().length()==0) {
                    Toast.makeText(RegistrationActivity.this, "Enter firstName", Toast.LENGTH_LONG).show();
                    firstName.requestFocus();
                }else if(lastName.getText().toString().length()==0){
                    Toast.makeText(RegistrationActivity.this, "Enter lastName", Toast.LENGTH_LONG).show();
                }else if(address.getText().toString().length()==0){
                    Toast.makeText(RegistrationActivity.this, "Enter address", Toast.LENGTH_LONG).show();

                }else if(mobileNo.getText().toString().length()==0){
                    Toast.makeText(RegistrationActivity.this, "Enter mobileno", Toast.LENGTH_LONG).show();
                }else if(emailID.getText().toString().length()==0&&emailID.getText().toString().length()!=0){
                    Toast.makeText(RegistrationActivity.this, "Enter valid emailAddress", Toast.LENGTH_LONG).show();
                    btnValidateEmailAddress(emailID);
                }else if(password.getText().toString().length()==0){
                    Toast.makeText(RegistrationActivity.this, "Enter password", Toast.LENGTH_LONG).show();

                }else{

                    WebUtil.getRegister(RegistrationActivity.this, firstName.getText().toString(),lastName.getText().toString(),address.getText().toString(), mobileNo.getText().toString(),emailID.getText().toString(), password.getText().toString(),new HandlerRegister());
                    Toast.makeText(getApplicationContext(),"Successfully Registered!!",Toast.LENGTH_LONG).show();

                }

            }
            public void btnValidateEmailAddress(View v)
            {
                strEmailAddress = emailID.getText().toString().trim();

                Matcher matcherObj = Pattern.compile(regEx).matcher(strEmailAddress);

                if (matcherObj.matches()) {
                    Toast.makeText(v.getContext(), strEmailAddress+" is valid", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(v.getContext(), strEmailAddress+" is InValid", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }





























    class HandlerRegister extends Handler
    {
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            if(msg!=null){
                String response= (String) msg.obj;
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    if(jsonObject.getString("Status").equalsIgnoreCase("true")){

                        Intent intent=new Intent(RegistrationActivity.this,LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d("test","error"+e.toString());
                }

            }
        }
    }
}
