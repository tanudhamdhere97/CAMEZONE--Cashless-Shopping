package com.squaretech.system.barcode.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squaretech.system.barcode.R;
import com.squaretech.system.barcode.entity.Product;

import java.util.ArrayList;

/**
 * Created by sopnil on 24/3/17.
 */
public class AdapterAddedItem extends BaseAdapter {

    Context context;
    ArrayList<Product> listOfProducts;

    public AdapterAddedItem(Context  context , ArrayList<Product> listOfProducts){
        this.context = context;
        this.listOfProducts = listOfProducts;
    }

    @Override
    public int getCount() {
        return listOfProducts.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        Holder holder;
        if (convertView == null){
            holder = new Holder();
            convertView = View.inflate(context , R.layout.list_item_added , null);
            holder.txtItem = (TextView) convertView.findViewById(R.id.txtItem);
            holder.imgCancel = (ImageView) convertView.findViewById(R.id.img_cancel);
            convertView.setTag(holder);
        }else {
            holder = (Holder) convertView.getTag();
        }

        holder.txtItem.setText(listOfProducts.get(position).getProductName() +  " - " + listOfProducts.get(position).getProductPrice() + "Rs" + "\n" + "Expiry : " + listOfProducts.get(position).getExpiary() );

        holder.imgCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                listOfProducts.remove(position);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }

    class Holder{
        TextView txtItem;
        ImageView imgCancel;
    }
}
