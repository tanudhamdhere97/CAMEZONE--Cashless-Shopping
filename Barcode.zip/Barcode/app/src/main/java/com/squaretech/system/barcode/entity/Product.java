package com.squaretech.system.barcode.entity;

/**
 * Created by sopnil on 22/3/17.
 */
public class Product {

    String productID;
    String productName;
    String productPrice;
    String productBarcode;
    String productStock;
    String expiary;


    public String getExpiary() {
        return expiary;
    }

    public void setExpiary(String expiary) {
        this.expiary = expiary;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductBarcode() {
        return productBarcode;
    }

    public void setProductBarcode(String productBarcode) {
        this.productBarcode = productBarcode;
    }

    public String getProductStock() {
        return productStock;
    }

    public void setProductStock(String productStock) {
        this.productStock = productStock;
    }
}
