package com.squaretech.system.barcode;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.client.android.CaptureActivity;
import com.squaretech.system.barcode.adapter.AdapterAddedItem;
import com.squaretech.system.barcode.entity.Product;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by sopnil on 20/3/17.
 */
public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Product> productArrayList;
    ArrayList<Product> listOfAddedItems = new ArrayList<>();
    AdapterAddedItem adapterAddedItem ;
    TextView txtAddItem  ,txtCheckout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main_actiivty);
        listView = (ListView) findViewById(R.id.list_view_products);
        WebUtil.getListOfProducts(this , new ProductHandler());

        txtAddItem = (TextView) findViewById(R.id.txtAddItem);
        txtCheckout = (TextView) findViewById(R.id.txtCheckout);


        txtAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (productArrayList != null && productArrayList.size()>0) {
                    Intent intent = new Intent(getApplicationContext(), CaptureActivity.class);
                    intent.setAction("com.google.zxing.client.android.SCAN");
                    intent.putExtra("SAVE_HISTORY", false);
                    startActivityForResult(intent, 0);
                }else {
                    Toast.makeText(MainActivity.this , "No Products Loaded , Please click refresh" , Toast.LENGTH_LONG).show();
                }
            }
        });

        txtCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int totalRupees=0;
                for (int j=0 ; j<listOfAddedItems.size(); j++){
                    totalRupees+=Integer.parseInt(listOfAddedItems.get(j).getProductPrice());
                }

                new AlertDialog.Builder(MainActivity.this)
                        .setMessage("Total bill: " + totalRupees)
                        .setPositiveButton("Pay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if (listOfAddedItems != null && listOfAddedItems.size() !=0) {
                                    listOfAddedItems.removeAll(listOfAddedItems);
                                    adapterAddedItem.notifyDataSetChanged();
                                    Toast.makeText(MainActivity.this, "Paid", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).show();
            }
        });
    }


    class ProductHandler extends Handler{
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            String response = (String) msg.obj;

            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(response.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                if(jsonObject.getString("Status").equalsIgnoreCase("true")){

                    productArrayList = new ArrayList<>();
                    JSONArray jsonArray = jsonObject.getJSONArray("products");
                    for (int i=0 ; i<jsonArray.length() ; i++){

                        Product product = new Product();
                        product.setProductName(jsonArray.getJSONObject(i).getString("name"));
                        product.setProductID(jsonArray.getJSONObject(i).getString("id"));
                        product.setProductBarcode(jsonArray.getJSONObject(i).getString("barcode"));
                        product.setProductPrice(jsonArray.getJSONObject(i).getString("price"));
                        product.setProductStock(jsonArray.getJSONObject(i).getString("stock"));
                        product.setExpiary(jsonArray.getJSONObject(i).getString("expiary"));

                        productArrayList.add(product);

                    }

//                    ArrayAdapter<String> itemsAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, productArrayList);
//                    listView.setAdapter(itemsAdapter);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                String contents = data.getStringExtra("SCAN_RESULT");


                for (int i=0 ; i<productArrayList.size() ; i++){
                    if(contents.equalsIgnoreCase(productArrayList.get(i).getProductBarcode())){
                        listOfAddedItems.add(productArrayList.get(i));
                    }
                }


                if (adapterAddedItem == null){
                    adapterAddedItem = new AdapterAddedItem(MainActivity.this , listOfAddedItems);
                    listView.setAdapter(adapterAddedItem);
                }else {
                    adapterAddedItem.notifyDataSetChanged();
                }


                Toast.makeText(MainActivity.this , contents , Toast.LENGTH_SHORT).show();
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(MainActivity.this , "No Item Added" , Toast.LENGTH_LONG).show();
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = MainActivity.this.getMenuInflater();
        menuInflater.inflate(R.menu.main , menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){

            case R.id.menu_logout:
                Pref.getmInstance(MainActivity.this).setLoginStatus(false);
                Intent intent = new Intent(MainActivity.this , LoginActivity.class);
                startActivity(intent);
                finish();
                break;

            case R.id.menu_refresh:
                WebUtil.getListOfProducts(this , new ProductHandler());
                break;

            default:

                break;
        }

        return super.onOptionsItemSelected(item);
    }
}
