package com.squaretech.system.barcode;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by squaretech on 1/3/17.
 */
public class LoginActivity extends AppCompatActivity {

    private Button btnLogin;
    private TextView txtReg;
    private EditText edtUsername , edtPass;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
    }

    private void initViews() {

        /// find id's by view
        btnLogin = (Button) findViewById(R.id.btn_login);
        txtReg = (TextView) findViewById(R.id.txt_register);
        edtUsername = (EditText) findViewById(R.id.edt_username);
        edtPass = (EditText) findViewById(R.id.edt_pass);


        // click for login button
        // this method will be called for login click
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(edtUsername.getText().toString().length()==0){
                    Toast.makeText(LoginActivity.this,"Enter username",Toast.LENGTH_LONG).show();
                }else if(edtPass.getText().toString().length()==0){
                    Toast.makeText(LoginActivity.this,"Enter password",Toast.LENGTH_LONG).show();

                }else if(edtUsername==RegistrationActivity.emailID && edtPass ==RegistrationActivity.password){
                    Intent intent = new Intent(LoginActivity.this , LoginActivity.class);
                    startActivity(intent);

                }else{
                    WebUtil.getLogin(LoginActivity.this, edtUsername.getText().toString(), edtPass.getText().toString(), new HandlerLogin());

                }
            }
        });

        // text view registration click
        txtReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginActivity.this,RegistrationActivity.class);
                startActivity(intent);
            }
        });
    }

    class HandlerLogin extends Handler {

        @Override
        public void handleMessage(Message msg) {

            super.handleMessage(msg);
            if (msg != null) {
                String response = (String) msg.obj;
                try {

                    JSONObject jsonObject = new JSONObject(response.toString());
                    if (jsonObject.getString("Status").equalsIgnoreCase("true")){
                        Pref.getmInstance(LoginActivity.this).setLoginStatus(true);
                        Toast.makeText(LoginActivity.this, "exist user", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(LoginActivity.this , MainActivity.class);
                        startActivity(intent);

                    }else {
                        Toast.makeText(LoginActivity.this, "UserName or Password Wrong", Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
