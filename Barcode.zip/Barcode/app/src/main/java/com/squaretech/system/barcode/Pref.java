package com.squaretech.system.barcode;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by sopnil on 30/12/16.
 */
public class Pref {

   public static Pref mInstance;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    private Pref(Context context){
        sharedPreferences = context.getSharedPreferences("MY_PREF" , context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }


    public static Pref getmInstance(Context context){

        if (mInstance == null){
            mInstance = new Pref(context);
        }

        return mInstance;
    }

    public void setLoginStatus(boolean loginStatus){
        editor.putBoolean("is_login" , loginStatus).commit();
    }

    public boolean getLoginStatus(){
        return sharedPreferences.getBoolean("is_login" , false);
    }


}
