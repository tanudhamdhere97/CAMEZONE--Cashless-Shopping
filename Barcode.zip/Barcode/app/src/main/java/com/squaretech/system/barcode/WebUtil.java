package com.squaretech.system.barcode;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by squaretech on 1/3/17.
 */
public class WebUtil {

    public static void getLogin(Context context , final String userName , final String password , final Handler handler){

        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Loading...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();

        String url ="http://linkcode.in/apps/barcode/register_login.php?";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                Message message = new Message();
                message.obj = response;
                handler.sendMessage(message);

                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String , String> params = new HashMap<>();
                params.put("cmd" , "login");
                params.put("username" , userName);
                params.put("password" , password);

                return params;
            }
        };
        VolleySingleton.getmInstance(context).getRequestQueue().add(stringRequest);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(30000, 2, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

    }


    public static void getRegister(Context context,final  String firstName,final  String lastName,final String address,final String mobileNo,final String emailID ,final String password,final Handler handler){

        final ProgressDialog progressDialog=new ProgressDialog(context);
        progressDialog.setMessage("Please wait..");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();

        String url="http://linkcode.in/apps/barcode/register_login.php?";
        StringRequest stringRequest=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Message message=new Message();
                message.obj=response;
                handler.sendMessage(message);
                progressDialog.dismiss();
                Log.d("test","new user in webutil"+response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String>param=new HashMap<>();
                param.put("cmd","register");
                param.put("firstName",firstName);
                param.put("lastName",lastName);
                param.put("address",address);
                param.put("mobileNo",mobileNo);
                param.put("username",emailID);
                param.put("password",password);
                return param;
            }
        };
        VolleySingleton.getmInstance(context).getRequestQueue().add(stringRequest);

    }



    public static void getListOfProducts(Context context  , final Handler handler){

        String url = "http://linkcode.in/apps/barcode/getProducts.php?";
        final ProgressDialog progressDialog=new ProgressDialog(context);
        progressDialog.setMessage("Loading products..");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();
                Message message = new Message();
                message.obj = response;
                handler.sendMessage(message);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String>param=new HashMap<>();
                param.put("cmd","get");

                return param;
            }
        };

        VolleySingleton.getmInstance(context).getRequestQueue().add(stringRequest);
    }

}


