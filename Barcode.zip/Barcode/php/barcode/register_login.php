<?php

include('opendb.php');
$cmd = $_REQUEST['cmd'];

if(strcmp($cmd, "register") == 0){

	register_user();
}
if(strcmp($cmd, "login") == 0){

	login_user();
}

	// register user 

	function register_user(){
	$firstName = $_REQUEST['firstName'];
	$lastName = $_REQUEST['lastName'];
	$address = $_REQUEST['address'];
	$mobileNo = $_REQUEST['mobileNo'];
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];
	
		$query = "INSERT INTO barcode(first_name , last_name , address ,mobile_no, username, password ) VALUES ('$firstName', '$lastName', '$address' ,'$mobileNo','$username','$password' )";	

			$queryResult = mysql_query($query)or die($query."<br/><br/>".mysql_error());
		
			if($queryResult){
				$resultStatus = 'true';
				$Message = "Registered Succesfully...";
				$userDetails = array();
				$responce = array('Status'=>$resultStatus, 'userID'=>strval(mysql_insert_id()), 'Message'=>$Message , 'userDetails'=>$userDetails);
				echo json_encode($responce);
			}
		
		}


	// login user
		
	function login_user(){
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];

	$query = "SELECT * FROM expence_user WHERE username = '$username' and password = '$password'";
	$queryResult = mysql_query($query)or die($query."<br/><br/>".mysql_error());
	$count = mysql_num_rows($queryResult);

		if($count > 0){	
				$resultStatus = 'true';
				$Message = "Login Succesfully...";
				$userDetails = array();
				while( $row = mysql_fetch_array($queryResult , MYSQL_ASSOC) ){		
						array_push($userDetails , $row);	
		   	 	}
				$responce = array('Status'=>$resultStatus, 'Message'=>$Message , 'userDetails'=>$userDetails);
				echo json_encode($responce);
		}
		else{
				$resultStatus = 'false';
				$Message = "Please Try Again...";
				$userDetails = array();
				$responce = array('Status'=>$resultStatus, 'Message'=>$Message , 'userDetails'=>$userDetails);
				echo json_encode($responce);

		}

}
?>
