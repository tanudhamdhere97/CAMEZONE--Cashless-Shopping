<?php
$servername="50.62.209.6:3306";
$username="rahul_ahire";
$password="Rpahire0708@";
$dbname="linkcode";
?>
