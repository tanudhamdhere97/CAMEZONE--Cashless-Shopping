<?php
include('root.php');
$con = mysql_connect("50.62.209.6:3306","rahul_ahire","Rpahire0708@");
 $dbName = "linkcode";
 mysql_select_db($dbName, $con);

if(!$con){
	die("Connection error :  " . mysql_get_last_message());	
}
?>
