<?php
include('opendb.php');
$cmd = $_REQUEST['cmd'];

if (strcmp($cmd, "get") == 0)
{
	getTransactions();
}

	
	function getTransactions(){
	
		$query ="SELECT * FROM barcode_product";
		$queryResult = mysql_query($query)or die($query."<br/><br/>".mysql_error());
	    	$count = mysql_num_rows($queryResult);

		if($count > 0){
		   $resultStatus = 'true';
		   $transactions = array();
			while( $row = mysql_fetch_array($queryResult , MYSQL_ASSOC) ){		
			array_push($transactions , $row);	
		    }
		}
		else{
			$resultStatus = 'false';
			$transactions = array();
		
		} 
		$responce = array('Status'=>$resultStatus , "products"=>$transactions);
		echo json_encode($responce);
	}
?>
